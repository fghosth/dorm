# 第一节

### CRM的十大误区
1. 营销就是CRM
2. 客户模型就是CRM
3. 微信就是CRM
4. 邮件（短信）就是CRM
5. 销售管理就是CRM
6. 开拓新客户不能用CRM
7. 电商不适合传统CRM
8. 用CRM一定赚钱，是直通车一样的神器
9. CRM是CRM专员的事情
10. CRM一定要有个系统落地


{% chart %}
{
    "chart": {
        "type": "bar"
    },
    "title": {
        "text": "Fruit Consumption"
    },
    "xAxis": {
        "categories": ["Apples", "Bananas", "Oranges"]
    },
    "yAxis": {
        "title": {
            "text": "Fruit eaten"
        }
    },
    "series": [{
        "name": "Jane",
        "data": [1, 0, 4]
    }, {
        "name": "John",
        "data": [5, 7, 3]
    }]
}
{% endchart %}




