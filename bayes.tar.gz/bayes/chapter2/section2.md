# 第二节
### 一张图看清CRM模型
![crmstruct](http://olro3azl7.bkt.clouddn.com/crmstruct.png)

&emsp;&emsp;&ensp;&ensp;不只是电子商务，分析的所有商业机构，基本的组成会有运营、市场、销售、客服、生产、库存、供应链、代理商、财务、行政、法务、审计等等。但真正跟客户关系相关的，涵盖运营、市场、销售、客服等最核心的组成部分。

&emsp;&emsp;&ensp;&ensp;CRM战略就是运营、营销、销售、服务等工作都将客户资料作为最基础的信息依据。


